package adivinhacao;

public class app {

	public static void main(String[] args) {
		Sistema s = new Sistema();
		
		s.menu(s);
	}
}
